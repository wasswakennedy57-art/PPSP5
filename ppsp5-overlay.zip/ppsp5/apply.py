#!/usr/bin/env python3
"""Turns a PPSSPP checkout into PPSP5.

Copies the PPSP5 launcher into the project and patches the Android build files:
  * new app id (the Java package stays org.ppsspp.ppsspp, so PPSSPP's native code keeps working)
  * the PPSP5 home screen becomes the app's launcher entry
  * ARM only (drops x86_64); set PPSP5_ABIS=arm64-only to also drop 32-bit ARM for a faster build

Run from the repository root:  python3 ppsp5/apply.py   (safe to run twice)
"""
import os
import re
import shutil
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.getcwd()
APP_ID = os.environ.get("PPSP5_APP_ID", "com.ppsp5.emulator")
ABIS = os.environ.get("PPSP5_ABIS", "both").strip().lower()
OLD_ID = "org.ppsspp.ppsspp"
LAUNCHER = "com.ppsp5.launcher.LauncherActivity"

MAIN_FILTER = re.compile(
    r'[ \t]*<intent-filter>\s*<action android:name="android\.intent\.action\.MAIN"\s*/>.*?</intent-filter>[ \t]*\r?\n?',
    re.S,
)

ACTIVITY = """
        <!-- PPSP5 home screen. This is the app's launcher entry; it starts PPSSPP's own activity to play games. -->
        <activity
            android:name="%s"
            android:exported="true"
            android:label="PPSP5"
            android:icon="@drawable/ppsp5_icon"
            android:theme="@android:style/Theme.Black.NoTitleBar.Fullscreen"
            android:screenOrientation="sensorLandscape"
            android:configChanges="orientation|screenSize|smallestScreenSize|screenLayout|keyboard|keyboardHidden|navigation|uiMode|density">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
                <category android:name="android.intent.category.LEANBACK_LAUNCHER" />
            </intent-filter>
        </activity>
""" % LAUNCHER


def read(path):
    with open(path, encoding="utf-8", newline="") as f:
        return f.read()


def write(path, text):
    with open(path, "w", encoding="utf-8", newline="") as f:
        f.write(text)


def die(msg):
    print("ERROR: " + msg)
    sys.exit(1)


def copy_overlay():
    src = os.path.join(HERE, "overlay")
    if not os.path.isdir(src):
        die("the overlay folder is missing next to apply.py")
    shutil.copytree(src, ROOT, dirs_exist_ok=True)
    print("copied the launcher files into the project")


def patch_gradle():
    path = os.path.join(ROOT, "android", "build.gradle.kts")
    if not os.path.isfile(path):
        die("android/build.gradle.kts not found. PPSSPP may have changed its Android build files.")
    s = read(path)
    old = 'applicationId = "%s"' % OLD_ID
    new = 'applicationId = "%s"' % APP_ID
    count = s.count(old)
    if count:
        s = s.replace(old, new)
    elif new not in s:
        die("could not find the applicationId line in android/build.gradle.kts")
    lines = s.split("\n")
    abi_lists = 0
    for i, line in enumerate(lines):
        if "abiFilters" not in line:
            continue
        abi_lists += 1
        line = re.sub(r',\s*"x86_64"', "", line)
        line = re.sub(r'"x86_64"\s*,\s*', "", line)
        if ABIS == "arm64-only":
            line = re.sub(r'"armeabi-v7a"\s*,\s*', "", line)
            line = re.sub(r',\s*"armeabi-v7a"', "", line)
        lines[i] = line
    s = "\n".join(lines)
    write(path, s)
    print("app id is now %s (%d change(s)); ABI lists trimmed: %d (mode: %s)" % (APP_ID, count, abi_lists, ABIS))


def patch_manifest():
    path = os.path.join(ROOT, "android", "AndroidManifest.xml")
    if not os.path.isfile(path):
        die("android/AndroidManifest.xml not found")
    s = read(path)
    if LAUNCHER in s:
        print("manifest already patched")
        return
    s, removed = MAIN_FILTER.subn("", s, count=1)
    if not removed:
        die("could not find PPSSPP's launcher entry in the manifest")
    s = s.replace('android:icon="@mipmap/ic_launcher"', 'android:icon="@drawable/ppsp5_icon"', 1)
    s = s.replace('android:label="@string/app_name"', 'android:label="PPSP5"', 1)
    end = s.rfind("</application>")
    if end < 0:
        die("no </application> tag in the manifest")
    s = s[:end] + ACTIVITY.lstrip("\n") + "    " + s[end:]
    write(path, s)
    print("manifest patched: PPSP5 launcher added, PPSSPP launcher entry removed")


def main():
    copy_overlay()
    patch_gradle()
    patch_manifest()
    print("PPSP5 overlay applied.")


if __name__ == "__main__":
    main()
