package com.ppsp5.launcher;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.DocumentsContract;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.DisplayCutout;
import android.view.Gravity;
import android.view.View;
import android.view.WindowInsets;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

/** PPSP5's own settings: home screen options, game folders and the most useful emulator options. */
public class SettingsActivity extends Activity {
    private static final int REQ_FOLDER = 4102;
    private static final int NAVY = 0xFF0A2A4D;

    private interface Choice {
        void onChoose(int index);
    }

    private Library lib;
    private EngineConfig cfg;
    private float density = 1f;
    private float unit = 1f;
    private FrameLayout root;
    private LinearLayout page;
    private LinearLayout content;

    // ------------------------------------------------------------ lifecycle

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        lib = new Library(this);
        DisplayMetrics dm = getResources().getDisplayMetrics();
        density = dm.density;
        float shortDp = Math.min(dm.widthPixels, dm.heightPixels) / dm.density;
        unit = Math.max(1f, Math.min(1.8f, shortDp / 360f));
        buildFrame();
        setContentView(root);
    }

    @Override
    protected void onResume() {
        super.onResume();
        hideSystemUi();
        // Read the emulator's settings file again: it may have just been created or rewritten.
        cfg = EngineConfig.open(this);
        buildContent();
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideSystemUi();
    }

    @SuppressWarnings("deprecation")
    private void hideSystemUi() {
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    }

    @SuppressWarnings("deprecation")
    private void applyInsets(View v, WindowInsets insets) {
        int l = insets.getSystemWindowInsetLeft();
        int t = insets.getSystemWindowInsetTop();
        int r = insets.getSystemWindowInsetRight();
        int b = insets.getSystemWindowInsetBottom();
        if (Build.VERSION.SDK_INT >= 28) {
            DisplayCutout cut = insets.getDisplayCutout();
            if (cut != null) {
                l = Math.max(l, cut.getSafeInsetLeft());
                t = Math.max(t, cut.getSafeInsetTop());
                r = Math.max(r, cut.getSafeInsetRight());
                b = Math.max(b, cut.getSafeInsetBottom());
            }
        }
        v.setPadding(d(32) + l, d(14) + t, d(32) + r, d(14) + b);
    }

    // ------------------------------------------------------------ small view helpers

    private int d(float v) {
        return Math.round(v * density * unit);
    }

    private LinearLayout.LayoutParams lp(int w, int h) {
        return new LinearLayout.LayoutParams(w, h);
    }

    private TextView label(String s, float sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextColor(color);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp * unit);
        t.setTypeface(Typeface.create("sans-serif-medium", bold ? Typeface.BOLD : Typeface.NORMAL));
        return t;
    }

    private TextView pill(String s, int fill, int textColor, View.OnClickListener click) {
        TextView t = label(s, 14, textColor, true);
        t.setGravity(Gravity.CENTER);
        t.setPadding(d(22), d(9), d(22), d(9));
        t.setMinHeight(d(42));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(fill);
        bg.setCornerRadius(d(24));
        t.setBackground(bg);
        t.setClickable(true);
        t.setOnClickListener(click);
        return t;
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_LONG).show();
    }

    // ------------------------------------------------------------ layout

    private void buildFrame() {
        root = new FrameLayout(this);
        root.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR,
            new int[] {0xFFEAF7FF, 0xFF9FD4F9, 0xFF4AA3E6}));

        page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(d(32), d(14), d(32), d(14));
        page.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
            @Override
            public WindowInsets onApplyWindowInsets(View v, WindowInsets insets) {
                applyInsets(v, insets);
                return insets;
            }
        });
        root.addView(page, new FrameLayout.LayoutParams(-1, -1));

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.addView(label("Settings", 24, NAVY, true), new LinearLayout.LayoutParams(0, -2, 1f));
        header.addView(pill("Done", NAVY, Color.WHITE, v -> finish()), lp(-2, -2));
        page.addView(header, lp(-1, -2));

        ScrollView scroll = new ScrollView(this);
        scroll.setVerticalScrollBarEnabled(false);
        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(0, 0, 0, d(24));
        scroll.addView(content, new FrameLayout.LayoutParams(-1, -2));
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, 0, 1f);
        sp.topMargin = d(6);
        page.addView(scroll, sp);
    }

    private void section(String title) {
        TextView t = label(title, 13, NAVY, true);
        LinearLayout.LayoutParams p = lp(-2, -2);
        p.topMargin = d(22);
        content.addView(t, p);
    }

    private void note(String s) {
        TextView t = label(s, 12, NAVY, false);
        t.setAlpha(0.8f);
        LinearLayout.LayoutParams p = lp(-1, -2);
        p.topMargin = d(8);
        content.addView(t, p);
    }

    private LinearLayout card() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(d(16), d(12), d(16), d(12));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0x99FFFFFF);
        bg.setCornerRadius(d(14));
        c.setBackground(bg);
        LinearLayout.LayoutParams p = lp(-1, -2);
        p.topMargin = d(10);
        content.addView(c, p);
        return c;
    }

    private void paint(TextView[] views, int selected) {
        for (int i = 0; i < views.length; i++) {
            boolean on = i == selected;
            GradientDrawable bg = new GradientDrawable();
            bg.setColor(on ? NAVY : 0xB3FFFFFF);
            bg.setCornerRadius(d(20));
            views[i].setBackground(bg);
            views[i].setTextColor(on ? Color.WHITE : NAVY);
        }
    }

    private View chips(String[] labels, int selected, final Choice choice) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        final TextView[] views = new TextView[labels.length];
        for (int i = 0; i < labels.length; i++) {
            final int index = i;
            TextView t = label(labels[i], 13, NAVY, true);
            t.setGravity(Gravity.CENTER);
            t.setPadding(d(16), d(8), d(16), d(8));
            t.setMinHeight(d(36));
            t.setClickable(true);
            t.setOnClickListener(v -> {
                paint(views, index);
                choice.onChoose(index);
            });
            LinearLayout.LayoutParams p = lp(-2, -2);
            p.rightMargin = d(8);
            row.addView(t, p);
            views[i] = t;
        }
        paint(views, selected);
        HorizontalScrollView sv = new HorizontalScrollView(this);
        sv.setHorizontalScrollBarEnabled(false);
        sv.addView(row, new FrameLayout.LayoutParams(-2, -2));
        return sv;
    }

    private void choiceRow(String title, String hint, String[] labels, int selected, Choice choice) {
        LinearLayout c = card();
        c.addView(label(title, 15, NAVY, true), lp(-2, -2));
        if (hint != null) {
            TextView h = label(hint, 12, NAVY, false);
            h.setAlpha(0.8f);
            c.addView(h, lp(-2, -2));
        }
        LinearLayout.LayoutParams p = lp(-1, -2);
        p.topMargin = d(8);
        c.addView(chips(labels, selected, choice), p);
    }

    /** One emulator option backed by a key in the emulator's own settings file. */
    private void engineRow(String title, String hint, final String section, final String key, String def,
                           String[] labels, final String[] values) {
        String cur = cfg.get(section, key, def);
        int sel = -1;
        if (cur != null) {
            for (int i = 0; i < values.length; i++) {
                if (values[i].equalsIgnoreCase(cur)) sel = i;
            }
        }
        choiceRow(title, hint, labels, sel, new Choice() {
            @Override
            public void onChoose(int index) {
                cfg.set(section, key, values[index]);
                if (!cfg.save()) toast("Couldn't save. Close the emulator first, then try again.");
            }
        });
    }

    private static String folderName(Uri tree) {
        try {
            String id = DocumentsContract.getTreeDocumentId(tree);
            int colon = id.indexOf(':');
            String vol = colon > 0 ? id.substring(0, colon) : id;
            String path = colon >= 0 ? id.substring(colon + 1) : "";
            String volName = "primary".equals(vol) ? "Internal storage" : "SD card (" + vol + ")";
            return path.isEmpty() ? volName : volName + " / " + path;
        } catch (Exception e) {
            return tree.toString();
        }
    }

    // ------------------------------------------------------------ content

    private void buildContent() {
        content.removeAllViews();

        section("HOME SCREEN");
        choiceRow("Start-up animation", null, new String[] {"On", "Off"}, lib.bootEnabled() ? 0 : 1, new Choice() {
            @Override
            public void onChoose(int index) {
                lib.setBootEnabled(index == 0);
            }
        });
        choiceRow("Sort games by", null, new String[] {"A to Z", "Recently played", "Most played"}, lib.sortMode(), new Choice() {
            @Override
            public void onChoose(int index) {
                lib.setSortMode(index);
            }
        });

        section("GAME FOLDERS");
        List<Uri> folders = lib.folders();
        if (folders.isEmpty()) {
            note("No folders yet. Add the folder where your PSP games are (ISO, CSO or PBP files).");
        }
        for (final Uri f : folders) {
            LinearLayout c = card();
            LinearLayout row = new LinearLayout(this);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.addView(label(folderName(f), 14, NAVY, false), new LinearLayout.LayoutParams(0, -2, 1f));
            row.addView(pill("Remove", 0xB3FFFFFF, NAVY, v -> {
                lib.removeFolder(f);
                buildContent();
            }), lp(-2, -2));
            c.addView(row, lp(-1, -2));
        }
        LinearLayout.LayoutParams addLp = lp(-2, -2);
        addLp.topMargin = d(10);
        content.addView(pill("+ Add folder", NAVY, Color.WHITE, v -> pickFolder()), addLp);

        section("EMULATOR");
        if (cfg == null) {
            note("Emulator options show up here once the emulator has created its settings file, which happens the first time a game runs. If you have already played and this stays empty, the emulator is using a different data folder.");
        } else {
            engineRow("Rendering resolution", "Higher looks sharper but needs a stronger phone.",
                "Graphics", "InternalResolution", null,
                new String[] {"Auto", "1x", "2x", "3x", "4x", "5x"}, new String[] {"0", "1", "2", "3", "4", "5"});
            engineRow("Frame skipping", "Skips frames so heavy games run faster.",
                "Graphics", "FrameSkip", "0",
                new String[] {"Off", "1", "2", "3"}, new String[] {"0", "1", "2", "3"});
            engineRow("Texture filtering", null,
                "Graphics", "TextureFiltering", "1",
                new String[] {"Auto", "Nearest", "Linear"}, new String[] {"1", "2", "3"});
            engineRow("Stretch to fill the screen", null,
                "Graphics", "DisplayStretch", "False",
                new String[] {"Off", "On"}, new String[] {"False", "True"});
            engineRow("Custom textures (mods)", "Loads replacement textures from the emulator's TEXTURES folder.",
                "Graphics", "ReplaceTextures", "True",
                new String[] {"On", "Off"}, new String[] {"True", "False"});
            engineRow("Sound", null,
                "Sound", "Enable", "True",
                new String[] {"On", "Off"}, new String[] {"True", "False"});
            engineRow("On-screen button opacity", null,
                "Control", "TouchButtonOpacity", "65",
                new String[] {"Faint", "Normal", "Solid"}, new String[] {"30", "65", "100"});
            engineRow("Vibration on touch", null,
                "Control", "HapticFeedback", "False",
                new String[] {"Off", "On"}, new String[] {"False", "True"});
            note("Changes apply to the next game you start. Leave a running game with Back, then Exit, before changing options.");
        }
        LinearLayout all = card();
        all.addView(label("All emulator options", 15, NAVY, true), lp(-2, -2));
        TextView hint = label("Graphics, audio, button mapping and everything else.", 12, NAVY, false);
        hint.setAlpha(0.8f);
        all.addView(hint, lp(-2, -2));
        LinearLayout.LayoutParams openLp = lp(-2, -2);
        openLp.topMargin = d(8);
        all.addView(pill("Open", NAVY, Color.WHITE, v -> {
            String err = Emulator.openSettings(this);
            if (err != null) toast("Couldn't open the emulator: " + err);
        }), openLp);
        if (cfg != null) {
            TextView where = label("Settings file: " + cfg.path(), 11, NAVY, false);
            where.setAlpha(0.6f);
            LinearLayout.LayoutParams wl = lp(-1, -2);
            wl.topMargin = d(10);
            content.addView(where, wl);
        }

        section("ABOUT");
        LinearLayout.LayoutParams aboutLp = lp(-2, -2);
        aboutLp.topMargin = d(10);
        content.addView(pill("About PPSP5", 0xB3FFFFFF, NAVY, v -> Emulator.showAbout(this)), aboutLp);
    }

    // ------------------------------------------------------------ folders

    private void pickFolder() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION
            | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION
            | Intent.FLAG_GRANT_PREFIX_URI_PERMISSION);
        try {
            startActivityForResult(i, REQ_FOLDER);
        } catch (Exception ex) {
            toast("No file picker found on this device.");
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req != REQ_FOLDER || res != RESULT_OK || data == null || data.getData() == null) return;
        Uri u = data.getData();
        try {
            getContentResolver().takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION);
        } catch (Exception ignored) {
            // Some providers can't persist access; the folder still works until the app restarts.
        }
        lib.addFolder(u);
        buildContent();
        toast("Folder added. Your games will show up on the home screen.");
    }
}
