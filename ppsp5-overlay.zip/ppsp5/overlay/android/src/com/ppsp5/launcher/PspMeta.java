package com.ppsp5.launcher;

import java.io.Closeable;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.util.Locale;
import java.util.zip.DataFormatException;
import java.util.zip.Inflater;

/** Reads title, disc id, ICON0 and PIC1 from PSP ISO, CSO and PBP files. Pure Java, no Android imports. */
final class PspMeta {
    String title;
    String discId;
    byte[] icon;
    byte[] pic;

    /** Random-access byte source. */
    interface Source extends Closeable {
        long length();

        /** Reads up to len bytes at offset. Returns the number of bytes read (fewer only at end of data). */
        int read(long offset, byte[] dst, int dstOff, int len) throws IOException;
    }

    /** Returns null when the file has no readable PSP metadata. */
    static PspMeta read(Source src, String fileName) throws IOException {
        String n = fileName == null ? "" : fileName.toLowerCase(Locale.US);
        if (n.endsWith(".pbp")) return readPbp(src);
        if (n.endsWith(".iso")) return readIso(src);
        if (n.endsWith(".cso")) {
            CsoSource cso = new CsoSource(src);
            try {
                return readIso(cso);
            } finally {
                cso.close();
            }
        }
        return null;
    }

    // ---------------------------------------------------------------- ISO

    private static PspMeta readIso(Source s) throws IOException {
        IsoFs fs = new IsoFs(s);
        byte[] sfo = fs.readFile("PSP_GAME/PARAM.SFO", 64 * 1024);
        if (sfo == null) return null;
        PspMeta m = new PspMeta();
        parseSfo(sfo, m);
        m.icon = fs.readFile("PSP_GAME/ICON0.PNG", 1 << 20);
        m.pic = fs.readFile("PSP_GAME/PIC1.PNG", 4 << 20);
        return m;
    }

    private static final class IsoFs {
        private final Source src;
        private final long rootLba;
        private final long rootLen;

        IsoFs(Source src) throws IOException {
            this.src = src;
            byte[] pvd = new byte[2048];
            if (src.read(16L * 2048, pvd, 0, 2048) < 2048) throw new IOException("No volume descriptor");
            if (pvd[0] != 1 || pvd[1] != 'C' || pvd[2] != 'D' || pvd[3] != '0' || pvd[4] != '0' || pvd[5] != '1') {
                throw new IOException("Not an ISO9660 image");
            }
            ByteBuffer b = ByteBuffer.wrap(pvd).order(ByteOrder.LITTLE_ENDIAN);
            rootLba = b.getInt(156 + 2) & 0xFFFFFFFFL;
            rootLen = b.getInt(156 + 10) & 0xFFFFFFFFL;
        }

        byte[] readFile(String path, int max) throws IOException {
            String[] parts = path.split("/");
            long lba = rootLba;
            long len = rootLen;
            for (int i = 0; i < parts.length; i++) {
                long[] e = lookup(lba, len, parts[i], i < parts.length - 1);
                if (e == null) return null;
                lba = e[0];
                len = e[1];
            }
            int n = (int) Math.min(len, (long) max);
            byte[] out = new byte[n];
            int got = src.read(lba * 2048L, out, 0, n);
            if (got < n) {
                byte[] cut = new byte[Math.max(got, 0)];
                System.arraycopy(out, 0, cut, 0, cut.length);
                return cut;
            }
            return out;
        }

        private long[] lookup(long lba, long len, String name, boolean wantDir) throws IOException {
            int size = (int) Math.min(len, 1L << 20);
            byte[] dir = new byte[size];
            int got = src.read(lba * 2048L, dir, 0, size);
            ByteBuffer b = ByteBuffer.wrap(dir).order(ByteOrder.LITTLE_ENDIAN);
            int off = 0;
            while (off < got) {
                int rl = dir[off] & 0xFF;
                if (rl == 0) {
                    off = (off / 2048 + 1) * 2048;
                    continue;
                }
                if (rl < 34 || off + rl > got) break;
                int nl = dir[off + 32] & 0xFF;
                if (off + 33 + nl > got) break;
                String n = new String(dir, off + 33, nl, StandardCharsets.US_ASCII);
                int semi = n.indexOf(';');
                if (semi >= 0) n = n.substring(0, semi);
                if (n.endsWith(".")) n = n.substring(0, n.length() - 1);
                boolean isDir = (dir[off + 25] & 2) != 0;
                if (isDir == wantDir && n.equalsIgnoreCase(name)) {
                    return new long[] {b.getInt(off + 2) & 0xFFFFFFFFL, b.getInt(off + 10) & 0xFFFFFFFFL};
                }
                off += rl;
            }
            return null;
        }
    }

    // ---------------------------------------------------------------- CSO

    /** Compressed ISO (CISO v1/v2 with deflate blocks). */
    private static final class CsoSource implements Source {
        private final Source base;
        private final long total;
        private final int blockSize;
        private final int shift;
        private final Inflater inflater = new Inflater(true);
        private byte[] cache;
        private long cacheBlock = -1;

        CsoSource(Source base) throws IOException {
            this.base = base;
            byte[] h = new byte[24];
            if (base.read(0, h, 0, 24) < 24) throw new IOException("Short CSO header");
            if (h[0] != 'C' || h[1] != 'I' || h[2] != 'S' || h[3] != 'O') throw new IOException("Not a CSO file");
            ByteBuffer b = ByteBuffer.wrap(h).order(ByteOrder.LITTLE_ENDIAN);
            total = b.getLong(8);
            blockSize = b.getInt(16);
            shift = h[21] & 0xFF;
            if (total <= 0 || blockSize < 512 || blockSize > (1 << 20)) throw new IOException("Bad CSO header");
        }

        @Override
        public long length() {
            return total;
        }

        private byte[] block(long bi) throws IOException {
            if (bi == cacheBlock) return cache;
            byte[] e = new byte[8];
            if (base.read(24 + bi * 4, e, 0, 8) < 8) throw new IOException("Short CSO index");
            ByteBuffer eb = ByteBuffer.wrap(e).order(ByteOrder.LITTLE_ENDIAN);
            int a = eb.getInt(0);
            int z = eb.getInt(4);
            boolean plain = (a & 0x80000000) != 0;
            long pos = ((long) (a & 0x7FFFFFFF)) << shift;
            long end = ((long) (z & 0x7FFFFFFF)) << shift;
            long clen = end - pos;
            if (clen < 0 || clen > 2L * blockSize + 1024) throw new IOException("Bad CSO block");
            byte[] comp = new byte[(int) clen];
            if (base.read(pos, comp, 0, comp.length) < comp.length) throw new IOException("Short CSO block");
            byte[] out = new byte[blockSize];
            if (plain) {
                System.arraycopy(comp, 0, out, 0, Math.min(comp.length, blockSize));
            } else {
                inflater.reset();
                inflater.setInput(comp);
                int n = 0;
                try {
                    while (n < blockSize && !inflater.finished()) {
                        int r = inflater.inflate(out, n, blockSize - n);
                        if (r == 0 && (inflater.needsInput() || inflater.needsDictionary())) break;
                        n += r;
                    }
                } catch (DataFormatException ex) {
                    throw new IOException("Corrupt CSO block");
                }
            }
            cache = out;
            cacheBlock = bi;
            return out;
        }

        @Override
        public int read(long offset, byte[] dst, int dstOff, int len) throws IOException {
            int done = 0;
            while (done < len && offset < total) {
                int bo = (int) (offset % blockSize);
                byte[] blk = block(offset / blockSize);
                long left = total - offset;
                int take = (int) Math.min((long) Math.min(len - done, blockSize - bo), left);
                System.arraycopy(blk, bo, dst, dstOff + done, take);
                done += take;
                offset += take;
            }
            return done;
        }

        @Override
        public void close() {
            inflater.end();
        }
    }

    // ---------------------------------------------------------------- PBP

    private static PspMeta readPbp(Source s) throws IOException {
        byte[] h = new byte[40];
        if (s.read(0, h, 0, 40) < 40) throw new IOException("Short PBP header");
        if (h[0] != 0 || h[1] != 'P' || h[2] != 'B' || h[3] != 'P') throw new IOException("Not a PBP file");
        ByteBuffer b = ByteBuffer.wrap(h).order(ByteOrder.LITTLE_ENDIAN);
        long[] off = new long[9];
        for (int i = 0; i < 8; i++) off[i] = b.getInt(8 + 4 * i) & 0xFFFFFFFFL;
        off[8] = s.length();
        // 0 PARAM.SFO, 1 ICON0.PNG, 2 ICON1.PMF, 3 PIC0.PNG, 4 PIC1.PNG, 5 SND0.AT3, 6 DATA.PSP, 7 DATA.PSAR
        byte[] sfo = slice(s, off[0], off[1], 64 * 1024);
        if (sfo == null || sfo.length == 0) return null;
        PspMeta m = new PspMeta();
        parseSfo(sfo, m);
        m.icon = slice(s, off[1], off[2], 1 << 20);
        m.pic = slice(s, off[4], off[5], 4 << 20);
        return m;
    }

    private static byte[] slice(Source s, long from, long to, int max) throws IOException {
        long n = Math.min(to - from, (long) max);
        if (n <= 0) return null;
        byte[] out = new byte[(int) n];
        int got = s.read(from, out, 0, out.length);
        return got == out.length ? out : null;
    }

    // ---------------------------------------------------------------- PARAM.SFO

    private static void parseSfo(byte[] d, PspMeta m) {
        if (d.length < 20) return;
        ByteBuffer b = ByteBuffer.wrap(d).order(ByteOrder.LITTLE_ENDIAN);
        if (b.getInt(0) != 0x46535000) return; // "\0PSF"
        int keys = b.getInt(8);
        int data = b.getInt(12);
        int count = b.getInt(16);
        for (int i = 0; i < count; i++) {
            int e = 20 + i * 16;
            if (e + 16 > d.length) break;
            int kOff = keys + (b.getShort(e) & 0xFFFF);
            int fmt = b.getShort(e + 2) & 0xFFFF;
            int len = b.getInt(e + 4);
            int dOff = data + b.getInt(e + 12);
            if (fmt != 0x0004 && fmt != 0x0204) continue;
            String key = cstr(d, kOff, d.length);
            if ("TITLE".equals(key)) m.title = cstr(d, dOff, Math.min(d.length, dOff + Math.max(len, 0)));
            else if ("DISC_ID".equals(key)) m.discId = cstr(d, dOff, Math.min(d.length, dOff + Math.max(len, 0)));
        }
        if (m.title != null) {
            m.title = m.title.trim();
            if (m.title.isEmpty()) m.title = null;
        }
    }

    private static String cstr(byte[] d, int start, int limit) {
        if (start < 0 || start >= d.length) return null;
        int end = start;
        while (end < limit && end < d.length && d[end] != 0) end++;
        return new String(d, start, end - start, StandardCharsets.UTF_8);
    }
}
