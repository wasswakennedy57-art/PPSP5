package com.ppsp5.launcher;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.net.Uri;

/** Starts PPSSPP's emulation activity the way a front end should: straight into the game, and closing when you leave it. */
final class Emulator {
    static final String ACTIVITY = "org.ppsspp.ppsspp.PpssppActivity";
    private static final String ARGS_KEY = "org.ppsspp.ppsspp.Args";

    private Emulator() {
    }

    private static Intent intent(Activity a, String action, String args) {
        Intent i = new Intent(action);
        i.setClassName(a, ACTIVITY);
        // PPSSPP reads command-line style options from this extra. The second key covers builds that derive it from the app id.
        i.putExtra(ARGS_KEY, args);
        i.putExtra(a.getPackageName() + ".Args", args);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        return i;
    }

    /** Starts a game. "Exit" in the pause menu then closes the emulator and drops you back on the PPSP5 home screen. */
    static String launchGame(Activity a, Uri game) {
        Intent i = intent(a, Intent.ACTION_VIEW, "--pause-menu-exit");
        i.setData(game);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        return start(a, i);
    }

    /** Opens the emulator's own settings screens (graphics, audio, controls and more). */
    static String openSettings(Activity a) {
        return start(a, intent(a, Intent.ACTION_MAIN, "--gamesettings"));
    }

    static void showAbout(Activity a) {
        new AlertDialog.Builder(a)
            .setTitle("PPSP5")
            .setMessage("PPSP5 (kit 2) is a PSP emulator built on the PPSSPP engine by Henrik Rydg\u00e5rd and contributors. "
                + "It is free software under the GNU GPL v2 or later.\n\n"
                + "You need your own legally obtained games. Add the folder that holds them in Settings.")
            .setPositiveButton("OK", null)
            .show();
    }

    /** Returns null on success, or a short error message. */
    private static String start(Activity a, Intent i) {
        try {
            a.startActivity(i);
            return null;
        } catch (Exception e) {
            return String.valueOf(e.getMessage());
        }
    }
}
