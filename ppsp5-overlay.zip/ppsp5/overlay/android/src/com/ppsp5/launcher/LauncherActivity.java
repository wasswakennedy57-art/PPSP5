package com.ppsp5.launcher;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Outline;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.util.LruCache;
import android.util.TypedValue;
import android.view.DisplayCutout;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewOutlineProvider;
import android.view.WindowInsets;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextClock;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** PPSP5 home screen: light-blue boot animation, a row of game tiles, one tap to play in the PPSSPP core. */
public class LauncherActivity extends Activity {
    private static final int REQ_FOLDER = 4101;
    private static final int NAVY = 0xFF0A2A4D;
    private static final String EMULATOR = "org.ppsspp.ppsspp.PpssppActivity";

    private final Handler ui = new Handler(Looper.getMainLooper());
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private final LruCache<String, Bitmap> icons = new LruCache<String, Bitmap>(80);

    private Library lib;
    private List<Game> games = new ArrayList<Game>();
    private volatile List<Game> pending;
    private int selected = -1;
    private float unit = 1f;
    private float density = 1f;
    private boolean destroyed;
    private String backdropKey = "";

    private FrameLayout root;
    private ImageView bgCur;
    private ImageView bgNext;
    private HorizontalScrollView scroller;
    private LinearLayout tileRow;
    private TextView titleView;
    private TextView metaView;
    private TextView playBtn;
    private TextView lastView;
    private TextView countView;
    private View infoCard;
    private BootView boot;

    // ------------------------------------------------------------ lifecycle

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        lib = new Library(this);
        DisplayMetrics dm = getResources().getDisplayMetrics();
        density = dm.density;
        float shortDp = Math.min(dm.widthPixels, dm.heightPixels) / dm.density;
        unit = Math.max(1f, Math.min(1.8f, shortDp / 360f));
        buildUi();
        setContentView(root);
        games = lib.loadCached();
        selected = indexOf(lib.lastSelected());
        if (selected < 0 && !games.isEmpty()) selected = 0;
        refreshTiles();
        if (state == null) showBoot();
        startRescan();
    }

    @Override
    protected void onResume() {
        super.onResume();
        hideSystemUi();
        bindSelection(false);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideSystemUi();
    }

    @Override
    protected void onDestroy() {
        destroyed = true;
        ui.removeCallbacksAndMessages(null);
        worker.shutdownNow();
        super.onDestroy();
    }

    @SuppressWarnings("deprecation")
    private void hideSystemUi() {
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    }

    // ------------------------------------------------------------ UI construction

    private int d(float v) {
        return Math.round(v * density * unit);
    }

    private LinearLayout.LayoutParams lp(int w, int h) {
        return new LinearLayout.LayoutParams(w, h);
    }

    private TextView label(String s, float sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextColor(color);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp * unit);
        t.setTypeface(Typeface.create("sans-serif-medium", bold ? Typeface.BOLD : Typeface.NORMAL));
        return t;
    }

    private TextView pill(String s, int fill, int textColor, View.OnClickListener click) {
        TextView t = label(s, 14, textColor, true);
        t.setGravity(Gravity.CENTER);
        t.setPadding(d(22), d(9), d(22), d(9));
        t.setMinHeight(d(42));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(fill);
        bg.setCornerRadius(d(24));
        t.setBackground(bg);
        t.setClickable(true);
        t.setOnClickListener(click);
        return t;
    }

    private ImageView backdropView() {
        ImageView v = new ImageView(this);
        v.setScaleType(ImageView.ScaleType.CENTER_CROP);
        return v;
    }

    private void buildUi() {
        root = new FrameLayout(this);
        root.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR,
            new int[] {0xFFEAF7FF, 0xFF9FD4F9, 0xFF4AA3E6}));

        bgCur = backdropView();
        bgNext = backdropView();
        bgNext.setAlpha(0f);
        root.addView(bgCur);
        root.addView(bgNext);

        View wash = new View(this);
        wash.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
            new int[] {0xD9EAF7FF, 0x80B9E1FF, 0xB36FB4EC}));
        root.addView(wash, new FrameLayout.LayoutParams(-1, -1));

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(d(32), d(14), d(32), d(20));
        col.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
            @Override
            public WindowInsets onApplyWindowInsets(View v, WindowInsets insets) {
                applyInsets(v, insets);
                return insets;
            }
        });
        root.addView(col, new FrameLayout.LayoutParams(-1, -1));

        // Top bar
        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        TextView tab = label("Games", 17, NAVY, true);
        tab.setPaintFlags(tab.getPaintFlags() | Paint.UNDERLINE_TEXT_FLAG);
        top.addView(tab, lp(-2, -2));
        top.addView(new View(this), new LinearLayout.LayoutParams(0, 1, 1f));
        top.addView(pill("+ Add folder", 0xB3FFFFFF, NAVY, v -> pickFolder()), lp(-2, -2));
        TextClock clock = new TextClock(this);
        clock.setFormat24Hour("HH:mm");
        clock.setFormat12Hour("h:mm a");
        clock.setTextColor(NAVY);
        clock.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15 * unit);
        LinearLayout.LayoutParams clp = lp(-2, -2);
        clp.leftMargin = d(16);
        top.addView(clock, clp);
        col.addView(top, lp(-1, -2));

        // Tile row
        scroller = new HorizontalScrollView(this);
        scroller.setHorizontalScrollBarEnabled(false);
        scroller.setOverScrollMode(View.OVER_SCROLL_NEVER);
        tileRow = new LinearLayout(this);
        tileRow.setOrientation(LinearLayout.HORIZONTAL);
        tileRow.setGravity(Gravity.CENTER_VERTICAL);
        tileRow.setPadding(0, d(18), d(60), d(18));
        scroller.addView(tileRow, new FrameLayout.LayoutParams(-2, -1));
        col.addView(scroller, lp(-1, d(128)));

        col.addView(new View(this), new LinearLayout.LayoutParams(-1, 0, 1f));

        // Bottom: title, buttons and info card
        LinearLayout bottom = new LinearLayout(this);
        bottom.setOrientation(LinearLayout.HORIZONTAL);
        bottom.setGravity(Gravity.BOTTOM);

        LinearLayout left = new LinearLayout(this);
        left.setOrientation(LinearLayout.VERTICAL);
        titleView = label("", 28, NAVY, true);
        titleView.setMaxLines(1);
        titleView.setEllipsize(TextUtils.TruncateAt.END);
        left.addView(titleView, lp(-1, -2));
        metaView = label("", 13, NAVY, false);
        metaView.setMaxLines(2);
        LinearLayout.LayoutParams mlp = lp(-1, -2);
        mlp.topMargin = d(4);
        left.addView(metaView, mlp);

        LinearLayout buttons = new LinearLayout(this);
        buttons.setGravity(Gravity.CENTER_VERTICAL);
        playBtn = pill("Play Game", NAVY, Color.WHITE, v -> launchSelected());
        buttons.addView(playBtn, lp(-2, -2));
        LinearLayout.LayoutParams moreLp = lp(-2, -2);
        moreLp.leftMargin = d(10);
        buttons.addView(pill("\u00b7\u00b7\u00b7", 0xB3FFFFFF, NAVY, v -> showMenu()), moreLp);
        LinearLayout.LayoutParams blp = lp(-2, -2);
        blp.topMargin = d(14);
        left.addView(buttons, blp);
        bottom.addView(left, new LinearLayout.LayoutParams(0, -2, 1f));

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(d(16), d(10), d(16), d(10));
        GradientDrawable cardBg = new GradientDrawable();
        cardBg.setColor(0x99FFFFFF);
        cardBg.setCornerRadius(d(14));
        card.setBackground(cardBg);
        lastView = label("", 12, NAVY, false);
        countView = label("", 12, NAVY, false);
        card.addView(lastView, lp(-2, -2));
        card.addView(countView, lp(-2, -2));
        infoCard = card;
        LinearLayout.LayoutParams cardLp = lp(-2, -2);
        cardLp.leftMargin = d(20);
        bottom.addView(card, cardLp);
        col.addView(bottom, lp(-1, -2));
    }

    /** Keeps the content clear of camera cut-outs and any visible system bars. */
    @SuppressWarnings("deprecation")
    private void applyInsets(View v, WindowInsets insets) {
        int l = insets.getSystemWindowInsetLeft();
        int t = insets.getSystemWindowInsetTop();
        int r = insets.getSystemWindowInsetRight();
        int b = insets.getSystemWindowInsetBottom();
        if (Build.VERSION.SDK_INT >= 28) {
            DisplayCutout cut = insets.getDisplayCutout();
            if (cut != null) {
                l = Math.max(l, cut.getSafeInsetLeft());
                t = Math.max(t, cut.getSafeInsetTop());
                r = Math.max(r, cut.getSafeInsetRight());
                b = Math.max(b, cut.getSafeInsetBottom());
            }
        }
        v.setPadding(d(32) + l, d(14) + t, d(32) + r, d(20) + b);
    }

    // ------------------------------------------------------------ tiles

    private ViewOutlineProvider rounded(final int radius) {
        return new ViewOutlineProvider() {
            @Override
            public void getOutline(View v, Outline outline) {
                outline.setRoundRect(0, 0, v.getWidth(), v.getHeight(), radius);
            }
        };
    }

    private static int tint(String s) {
        float hue = 195f + Math.abs(s.hashCode() % 40);
        return Color.HSVToColor(new float[] {hue, 0.28f, 0.97f});
    }

    private static String initials(String s) {
        StringBuilder sb = new StringBuilder();
        for (String w : s.trim().split("\\s+")) {
            if (!w.isEmpty() && Character.isLetterOrDigit(w.charAt(0))) sb.append(Character.toUpperCase(w.charAt(0)));
            if (sb.length() == 2) break;
        }
        return sb.length() == 0 ? "?" : sb.toString();
    }

    private Bitmap icon(Game g) {
        String p = g.iconPath;
        if (p == null) return null;
        Bitmap b = icons.get(p);
        if (b == null) {
            b = BitmapFactory.decodeFile(p);
            if (b != null) icons.put(p, b);
        }
        return b;
    }

    private View makeAddTile() {
        FrameLayout t = new FrameLayout(this);
        LinearLayout.LayoutParams p = lp(d(74), d(74));
        p.rightMargin = d(14);
        t.setLayoutParams(p);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xB3FFFFFF);
        bg.setCornerRadius(d(10));
        t.setBackground(bg);
        TextView plus = label("+", 30, NAVY, false);
        plus.setGravity(Gravity.CENTER);
        t.addView(plus, new FrameLayout.LayoutParams(-1, -1));
        t.setClickable(true);
        t.setContentDescription("Add games folder");
        t.setOnClickListener(v -> pickFolder());
        return t;
    }

    private View makeTile(final int index) {
        Game g = games.get(index);
        FrameLayout t = new FrameLayout(this);
        LinearLayout.LayoutParams p = lp(d(132), d(74));
        p.rightMargin = d(14);
        t.setLayoutParams(p);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(tint(g.displayTitle()));
        bg.setCornerRadius(d(10));
        t.setBackground(bg);
        t.setOutlineProvider(rounded(d(10)));
        t.setClipToOutline(true);
        Bitmap icon = icon(g);
        if (icon != null) {
            ImageView iv = new ImageView(this);
            iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
            iv.setImageBitmap(icon);
            t.addView(iv, new FrameLayout.LayoutParams(-1, -1));
        } else {
            TextView ini = label(initials(g.displayTitle()), 20, NAVY, true);
            ini.setGravity(Gravity.CENTER);
            t.addView(ini, new FrameLayout.LayoutParams(-1, -1));
        }
        t.setClickable(true);
        t.setContentDescription(g.displayTitle());
        t.setOnClickListener(v -> onTile(index));
        return t;
    }

    private void refreshTiles() {
        tileRow.removeAllViews();
        tileRow.addView(makeAddTile());
        for (int i = 0; i < games.size(); i++) tileRow.addView(makeTile(i));
        bindSelection(false);
        centerSelected();
    }

    private GradientDrawable ring() {
        GradientDrawable r = new GradientDrawable();
        r.setColor(Color.TRANSPARENT);
        r.setStroke(d(3), Color.WHITE);
        r.setCornerRadius(d(10));
        return r;
    }

    private void bindSelection(boolean animate) {
        for (int i = 0; i < games.size(); i++) {
            View t = tileRow.getChildAt(i + 1);
            if (!(t instanceof FrameLayout)) continue;
            boolean sel = i == selected;
            float s = sel ? 1.2f : 0.9f;
            float a = sel ? 1f : 0.8f;
            ((FrameLayout) t).setForeground(sel ? ring() : null);
            t.setElevation(sel ? d(10) : 0f);
            if (animate) {
                t.animate().scaleX(s).scaleY(s).alpha(a).setDuration(150).start();
            } else {
                t.setScaleX(s);
                t.setScaleY(s);
                t.setAlpha(a);
            }
        }

        Game g = current();
        if (g == null) {
            titleView.setText(games.isEmpty() ? "No games yet" : "");
            metaView.setText("Tap + to choose the folder where your PSP games are (ISO, CSO or PBP).");
            playBtn.setVisibility(View.GONE);
            infoCard.setVisibility(View.GONE);
            setBackdrop(null);
            return;
        }
        playBtn.setVisibility(View.VISIBLE);
        infoCard.setVisibility(View.VISIBLE);
        titleView.setText(g.displayTitle());
        metaView.setText(metaLine(g));
        long last = lib.lastPlayed(g);
        lastView.setText("Last played   "
            + (last == 0L ? "never" : DateFormat.getDateInstance(DateFormat.MEDIUM).format(new Date(last))));
        countView.setText("Times played   " + lib.playCount(g));
        setBackdrop(g);
        lib.setLastSelected(g.uri.toString());
    }

    private void centerSelected() {
        scroller.post(new Runnable() {
            @Override
            public void run() {
                View t = tileRow.getChildAt(selected + 1);
                if (t == null || selected < 0) return;
                int x = t.getLeft() - (scroller.getWidth() - t.getWidth()) / 2;
                scroller.smoothScrollTo(Math.max(0, x), 0);
            }
        });
    }

    private Game current() {
        return selected >= 0 && selected < games.size() ? games.get(selected) : null;
    }

    private int indexOf(String uri) {
        if (uri == null) return -1;
        for (int i = 0; i < games.size(); i++) {
            if (uri.equals(games.get(i).uri.toString())) return i;
        }
        return -1;
    }

    private void select(int index) {
        if (index == selected || index < 0 || index >= games.size()) return;
        selected = index;
        bindSelection(true);
        centerSelected();
    }

    private void move(int delta) {
        if (games.isEmpty()) return;
        int next = selected < 0 ? 0 : Math.max(0, Math.min(games.size() - 1, selected + delta));
        select(next);
    }

    private void onTile(int index) {
        if (index == selected) launchSelected();
        else select(index);
    }

    private static String metaLine(Game g) {
        StringBuilder sb = new StringBuilder();
        if (g.discId != null && !g.discId.isEmpty()) sb.append(g.discId).append("  \u00b7  ");
        sb.append(g.ext());
        if (g.size > 0) sb.append("  \u00b7  ").append(formatSize(g.size));
        return sb.toString();
    }

    private static String formatSize(long bytes) {
        double gb = bytes / 1073741824.0;
        if (gb >= 1.0) return String.format(Locale.US, "%.1f GB", gb);
        return String.format(Locale.US, "%d MB", Math.max(1L, bytes / 1048576L));
    }

    // ------------------------------------------------------------ backdrop

    private void setBackdrop(Game g) {
        String key = g == null ? "" : g.key() + (g.picPath != null ? "p" : (g.iconPath != null ? "i" : "n"));
        if (key.equals(backdropKey)) return;
        backdropKey = key;
        Bitmap b = null;
        if (g != null) {
            String path = g.picPath != null ? g.picPath : g.iconPath;
            if (path != null) b = softened(path);
        }
        bgNext.setImageBitmap(b);
        bgNext.setAlpha(0f);
        bgNext.animate().alpha(1f).setDuration(280).start();
        bgCur.animate().alpha(0f).setDuration(280).start();
        ImageView tmp = bgCur;
        bgCur = bgNext;
        bgNext = tmp;
    }

    /** Shrinks the art to a few dozen pixels; stretched back up it becomes a soft blurred backdrop. */
    private static Bitmap softened(String path) {
        Bitmap full = BitmapFactory.decodeFile(path);
        if (full == null) return null;
        Bitmap small = Bitmap.createScaledBitmap(full,
            Math.max(16, full.getWidth() / 10), Math.max(9, full.getHeight() / 10), true);
        if (small != full) full.recycle();
        return small;
    }

    // ------------------------------------------------------------ boot animation

    private void showBoot() {
        final BootView bv = new BootView(this);
        boot = bv;
        bv.setOnClickListener(v -> bv.skip());
        bv.setListener(new BootView.Listener() {
            @Override
            public void onFinished() {
                endBoot();
            }
        });
        root.addView(bv, new FrameLayout.LayoutParams(-1, -1));
        bv.start();
    }

    private void endBoot() {
        final BootView bv = boot;
        if (bv == null) return;
        boot = null;
        bv.animate().alpha(0f).setDuration(450).withEndAction(new Runnable() {
            @Override
            public void run() {
                root.removeView(bv);
            }
        }).start();
    }

    // ------------------------------------------------------------ input

    @Override
    public boolean dispatchKeyEvent(KeyEvent e) {
        if (e.getAction() == KeyEvent.ACTION_DOWN) {
            int code = e.getKeyCode();
            if (boot != null && code != KeyEvent.KEYCODE_BACK) {
                boot.skip();
                return true;
            }
            switch (code) {
                case KeyEvent.KEYCODE_DPAD_LEFT:
                    move(-1);
                    return true;
                case KeyEvent.KEYCODE_DPAD_RIGHT:
                    move(1);
                    return true;
                case KeyEvent.KEYCODE_DPAD_CENTER:
                case KeyEvent.KEYCODE_ENTER:
                case KeyEvent.KEYCODE_BUTTON_A:
                    launchSelected();
                    return true;
                case KeyEvent.KEYCODE_BUTTON_START:
                case KeyEvent.KEYCODE_MENU:
                    showMenu();
                    return true;
                default:
                    break;
            }
        }
        return super.dispatchKeyEvent(e);
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_LONG).show();
    }

    private void showMenu() {
        final String[] items = {
            "Add games folder", "Rescan library", "Emulator menu and settings", "Forget all folders", "About PPSP5"
        };
        new AlertDialog.Builder(this).setItems(items, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                switch (which) {
                    case 0:
                        pickFolder();
                        break;
                    case 1:
                        startRescan();
                        break;
                    case 2:
                        openEmulator();
                        break;
                    case 3:
                        lib.clearFolders();
                        games = new ArrayList<Game>();
                        selected = -1;
                        backdropKey = "";
                        refreshTiles();
                        break;
                    default:
                        about();
                        break;
                }
            }
        }).show();
    }

    private void about() {
        new AlertDialog.Builder(this)
            .setTitle("PPSP5")
            .setMessage("PPSP5 is a PSP emulator front end built on PPSSPP by Henrik Rydg\u00e5rd and contributors. "
                + "It is free software under the GNU GPL v2 or later.\n\n"
                + "You need your own legally obtained games. Add the folder that holds them with the + button.")
            .setPositiveButton("OK", null)
            .show();
    }

    // ------------------------------------------------------------ folders and scanning

    private void pickFolder() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION
            | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION
            | Intent.FLAG_GRANT_PREFIX_URI_PERMISSION);
        try {
            startActivityForResult(i, REQ_FOLDER);
        } catch (Exception ex) {
            toast("No file picker found on this device.");
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req != REQ_FOLDER || res != RESULT_OK || data == null || data.getData() == null) return;
        Uri u = data.getData();
        try {
            getContentResolver().takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION);
        } catch (Exception ignored) {
            // Some providers can't persist access; the folder still works until the app restarts.
        }
        lib.addFolder(u);
        toast("Scanning your games...");
        startRescan();
    }

    private final Runnable applyPending = new Runnable() {
        @Override
        public void run() {
            List<Game> p = pending;
            if (p == null || destroyed) return;
            pending = null;
            Game cur = current();
            String keep = cur != null ? cur.uri.toString() : lib.lastSelected();
            games = p;
            selected = indexOf(keep);
            if (selected < 0 && !games.isEmpty()) selected = 0;
            refreshTiles();
        }
    };

    private void post(List<Game> list, boolean now) {
        pending = list;
        ui.removeCallbacks(applyPending);
        ui.postDelayed(applyPending, now ? 0L : 300L);
    }

    private void startRescan() {
        final List<Game> cached = new ArrayList<Game>(games);
        worker.execute(new Runnable() {
            @Override
            public void run() {
                List<Game> result = lib.rescan(cached, new Library.Progress() {
                    @Override
                    public void onUpdate(List<Game> snapshot) {
                        post(snapshot, false);
                    }
                });
                post(result, true);
            }
        });
    }

    // ------------------------------------------------------------ starting the emulator

    private void launchSelected() {
        Game g = current();
        if (g != null) launch(g);
    }

    private void launch(Game g) {
        lib.markPlayed(g);
        Intent i = new Intent(Intent.ACTION_VIEW);
        i.setClassName(this, EMULATOR);
        i.setData(g.uri);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION
            | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION
            | Intent.FLAG_ACTIVITY_NEW_TASK
            | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        try {
            startActivity(i);
        } catch (Exception ex) {
            toast("Couldn't start the emulator: " + ex.getMessage());
        }
    }

    private void openEmulator() {
        Intent i = new Intent(Intent.ACTION_MAIN);
        i.setClassName(this, EMULATOR);
        try {
            startActivity(i);
        } catch (Exception ex) {
            toast("Couldn't start the emulator: " + ex.getMessage());
        }
    }
}
