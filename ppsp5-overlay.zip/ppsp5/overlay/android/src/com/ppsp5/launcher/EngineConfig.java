package com.ppsp5.launcher;

import android.content.Context;
import android.os.Environment;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/** Reads and edits the emulator's ppsspp.ini so PPSP5's own settings screen can change engine options. */
final class EngineConfig {
    private final File file;
    private final List<String> lines = new ArrayList<String>();
    private boolean dirty;

    private EngineConfig(File file) {
        this.file = file;
    }

    /** Finds the emulator's settings file. Returns null until the emulator has run once and created it. */
    static EngineConfig open(Context c) {
        List<File> candidates = new ArrayList<File>();
        File own = c.getExternalFilesDir(null);
        if (own != null) candidates.add(new File(own, "PSP/SYSTEM/ppsspp.ini"));
        File shared = Environment.getExternalStorageDirectory();
        if (shared != null) candidates.add(new File(shared, "PSP/SYSTEM/ppsspp.ini"));
        for (File f : candidates) {
            EngineConfig e = fromFile(f);
            if (e != null) return e;
        }
        return null;
    }

    static EngineConfig fromFile(File f) {
        if (f == null || !f.isFile() || !f.canRead() || !f.canWrite()) return null;
        EngineConfig e = new EngineConfig(f);
        try {
            e.load();
        } catch (IOException ex) {
            return null;
        }
        return e;
    }

    String path() {
        return file.getPath();
    }

    private void load() throws IOException {
        BufferedReader r = new BufferedReader(new InputStreamReader(new FileInputStream(file), StandardCharsets.UTF_8));
        try {
            String line;
            while ((line = r.readLine()) != null) lines.add(line);
        } finally {
            r.close();
        }
    }

    private static boolean isHeader(String line) {
        String t = line.trim();
        return t.startsWith("[") && t.endsWith("]");
    }

    private int findSection(String section) {
        String header = "[" + section + "]";
        for (int i = 0; i < lines.size(); i++) {
            if (header.equals(lines.get(i).trim())) return i;
        }
        return -1;
    }

    private static String valueOf(String line, String key) {
        int eq = line.indexOf('=');
        if (eq <= 0) return null;
        if (!line.substring(0, eq).trim().equals(key)) return null;
        return line.substring(eq + 1).trim();
    }

    /** Returns the stored value, or def when the key isn't in the file (the emulator is then using its own default). */
    String get(String section, String key, String def) {
        int s = findSection(section);
        if (s < 0) return def;
        for (int i = s + 1; i < lines.size() && !isHeader(lines.get(i)); i++) {
            String v = valueOf(lines.get(i), key);
            if (v != null) return v;
        }
        return def;
    }

    void set(String section, String key, String value) {
        String entry = key + " = " + value;
        int s = findSection(section);
        if (s < 0) {
            if (!lines.isEmpty() && !lines.get(lines.size() - 1).trim().isEmpty()) lines.add("");
            lines.add("[" + section + "]");
            lines.add(entry);
            dirty = true;
            return;
        }
        int end = s + 1;
        while (end < lines.size() && !isHeader(lines.get(end))) {
            if (valueOf(lines.get(end), key) != null) {
                lines.set(end, entry);
                dirty = true;
                return;
            }
            end++;
        }
        int at = end;
        while (at > s + 1 && lines.get(at - 1).trim().isEmpty()) at--;
        lines.add(at, entry);
        dirty = true;
    }

    /** Writes changes back. Keeps a one-time copy of the original file next to it. */
    boolean save() {
        if (!dirty) return true;
        try {
            File backup = new File(file.getParentFile(), "ppsspp.ini.ppsp5-backup");
            if (!backup.exists()) copy(file, backup);
            Writer w = new OutputStreamWriter(new FileOutputStream(file), StandardCharsets.UTF_8);
            try {
                for (String l : lines) {
                    w.write(l);
                    w.write("\n");
                }
            } finally {
                w.close();
            }
            dirty = false;
            return true;
        } catch (IOException e) {
            return false;
        }
    }

    private static void copy(File from, File to) throws IOException {
        FileInputStream in = new FileInputStream(from);
        try {
            FileOutputStream out = new FileOutputStream(to);
            try {
                byte[] buf = new byte[8192];
                int n;
                while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            } finally {
                out.close();
            }
        } finally {
            in.close();
        }
    }
}
