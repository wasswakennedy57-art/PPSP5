package com.ppsp5.launcher;

import android.os.ParcelFileDescriptor;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;

/** Random-access reader over a ParcelFileDescriptor (closing it closes the descriptor). */
final class FdSource implements PspMeta.Source {
    private final ParcelFileDescriptor.AutoCloseInputStream in;
    private final FileChannel ch;
    private final long len;

    FdSource(ParcelFileDescriptor pfd) throws IOException {
        in = new ParcelFileDescriptor.AutoCloseInputStream(pfd);
        FileChannel c = in.getChannel();
        long n;
        try {
            n = c.size();
        } catch (IOException e) {
            in.close();
            throw e;
        }
        ch = c;
        len = n;
    }

    @Override
    public long length() {
        return len;
    }

    @Override
    public int read(long offset, byte[] dst, int dstOff, int n) throws IOException {
        ByteBuffer bb = ByteBuffer.wrap(dst, dstOff, n);
        int total = 0;
        while (total < n) {
            int r = ch.read(bb, offset + total);
            if (r <= 0) break;
            total += r;
        }
        return total;
    }

    @Override
    public void close() throws IOException {
        in.close();
    }
}
