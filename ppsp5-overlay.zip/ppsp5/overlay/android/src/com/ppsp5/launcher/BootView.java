package com.ppsp5.launcher;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.view.View;
import android.view.animation.LinearInterpolator;

import java.util.Random;

/** Light-blue start-up animation: a spotlight beam, drifting particles and the PPSP5 wordmark. */
final class BootView extends View {
    interface Listener {
        void onFinished();
    }

    private static final float SECONDS = 3.6f;
    private static final int N = 28;

    private final Paint bg = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint beam = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint dot = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint word = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path beamPath = new Path();
    private final float[] px = new float[N];
    private final float[] py = new float[N];
    private final float[] ps = new float[N];
    private final float[] pv = new float[N];
    private final float[] pp = new float[N];
    private ValueAnimator anim;
    private Listener listener;
    private float t;
    private boolean done;

    BootView(Context context) {
        super(context);
        Random r = new Random(7);
        for (int i = 0; i < N; i++) {
            px[i] = r.nextFloat();
            py[i] = r.nextFloat();
            ps[i] = 0.003f + r.nextFloat() * 0.007f;
            pv[i] = 0.02f + r.nextFloat() * 0.05f;
            pp[i] = r.nextFloat() * 6.28f;
        }
        word.setColor(0xFF0A2A4D);
        word.setTextAlign(Paint.Align.CENTER);
        word.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        word.setLetterSpacing(0.06f);
    }

    void setListener(Listener l) {
        listener = l;
    }

    void start() {
        anim = ValueAnimator.ofFloat(0f, SECONDS);
        anim.setDuration((long) (SECONDS * 1000f));
        anim.setInterpolator(new LinearInterpolator());
        anim.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator a) {
                t = (Float) a.getAnimatedValue();
                invalidate();
            }
        });
        anim.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(Animator a) {
                complete();
            }
        });
        anim.start();
    }

    void skip() {
        if (anim != null && anim.isRunning()) anim.cancel();
        else complete();
    }

    private void complete() {
        if (done) return;
        done = true;
        if (listener != null) listener.onFinished();
    }

    @Override
    protected void onDetachedFromWindow() {
        listener = null;
        if (anim != null) anim.cancel();
        super.onDetachedFromWindow();
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        bg.setShader(new LinearGradient(0, 0, 0, h,
            new int[] {0xFFF2F9FF, 0xFFB9E1FF, 0xFF6FB4EC}, new float[] {0f, 0.55f, 1f}, Shader.TileMode.CLAMP));
        beam.setShader(new LinearGradient(0, 0, 0, h, 0xF2FFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP));
        beamPath.reset();
        beamPath.moveTo(w * 0.14f, 0f);
        beamPath.lineTo(w * 0.34f, 0f);
        beamPath.lineTo(w * 0.86f, h);
        beamPath.lineTo(w * 0.26f, h);
        beamPath.close();
        line.setShader(new LinearGradient(w * 0.4f, 0, w * 0.6f, 0,
            new int[] {0x002D9CFF, 0xFF2D9CFF, 0x002D9CFF}, null, Shader.TileMode.CLAMP));
        word.setTextSize(Math.min(h * 0.2f, w * 0.14f));
    }

    private static float ease(float x) {
        if (x <= 0f) return 0f;
        if (x >= 1f) return 1f;
        return x * x * (3f - 2f * x);
    }

    @Override
    protected void onDraw(Canvas c) {
        float w = getWidth();
        float h = getHeight();
        c.drawRect(0f, 0f, w, h, bg);

        beam.setAlpha((int) (255f * ease(t)));
        c.drawPath(beamPath, beam);

        float pa = ease((t - 0.2f) / 0.8f);
        for (int i = 0; i < N; i++) {
            float x = ((px[i] + t * pv[i] * 0.6f) % 1f) * w;
            float y = (((py[i] - t * pv[i] * 0.35f) % 1f + 1f) % 1f) * h;
            float twinkle = 0.55f + 0.45f * (float) Math.sin(t * 2.2f + pp[i]);
            dot.setColor(i % 4 == 0 ? 0xFF2D9CFF : 0xFFFFFFFF);
            dot.setAlpha((int) (255f * pa * Math.max(0.15f, twinkle)));
            c.drawCircle(x, y, ps[i] * h, dot);
        }

        float wa = ease((t - 0.7f) / 0.9f);
        if (wa > 0f) {
            float sc = 0.92f + 0.08f * wa;
            word.setAlpha((int) (255f * wa));
            c.save();
            c.scale(sc, sc, w / 2f, h / 2f);
            c.drawText("PPSP5", w / 2f, h * 0.5f + word.getTextSize() * 0.35f, word);
            c.restore();
        }

        float la = ease((t - 1.3f) / 0.8f);
        if (la > 0f) {
            line.setAlpha((int) (255f * la));
            float top = h * 0.66f;
            c.drawRoundRect(w * 0.4f, top, w * 0.6f, top + Math.max(3f, h * 0.007f), 6f, 6f, line);
        }
    }
}
