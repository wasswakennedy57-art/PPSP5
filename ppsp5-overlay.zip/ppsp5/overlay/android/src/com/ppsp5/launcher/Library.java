package com.ppsp5.launcher;

import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.provider.DocumentsContract;
import android.provider.DocumentsContract.Document;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/** Finds games in the folders the user picked, reads their art/titles and remembers the result. */
final class Library {
    interface Progress {
        void onUpdate(List<Game> snapshot);
    }

    private static final String[] COLS = {
        Document.COLUMN_DOCUMENT_ID,
        Document.COLUMN_DISPLAY_NAME,
        Document.COLUMN_MIME_TYPE,
        Document.COLUMN_SIZE,
        Document.COLUMN_LAST_MODIFIED
    };

    private final Context ctx;
    private final SharedPreferences prefs;
    private final File dir;

    Library(Context c) {
        ctx = c.getApplicationContext();
        prefs = ctx.getSharedPreferences("ppsp5", Context.MODE_PRIVATE);
        dir = new File(ctx.getFilesDir(), "library");
        if (!dir.exists()) dir.mkdirs();
    }

    // ------------------------------------------------------------ settings

    List<Uri> folders() {
        List<Uri> out = new ArrayList<>();
        Set<String> s = prefs.getStringSet("folders", null);
        if (s != null) {
            for (String x : s) out.add(Uri.parse(x));
        }
        return out;
    }

    void addFolder(Uri u) {
        Set<String> s = new HashSet<>();
        Set<String> old = prefs.getStringSet("folders", null);
        if (old != null) s.addAll(old);
        s.add(u.toString());
        prefs.edit().putStringSet("folders", s).apply();
    }

    void removeFolder(Uri u) {
        Set<String> s = new HashSet<>();
        Set<String> old = prefs.getStringSet("folders", null);
        if (old != null) s.addAll(old);
        s.remove(u.toString());
        prefs.edit().putStringSet("folders", s).apply();
    }

    boolean bootEnabled() {
        return prefs.getBoolean("boot", true);
    }

    void setBootEnabled(boolean on) {
        prefs.edit().putBoolean("boot", on).apply();
    }

    /** 0 = A to Z, 1 = recently played, 2 = most played. */
    int sortMode() {
        return prefs.getInt("sort", 0);
    }

    void setSortMode(int mode) {
        prefs.edit().putInt("sort", mode).apply();
    }

    void clearFolders() {
        prefs.edit().remove("folders").remove("last").apply();
        File[] files = dir.listFiles();
        if (files != null) {
            for (File f : files) f.delete();
        }
    }

    String lastSelected() {
        return prefs.getString("last", null);
    }

    void setLastSelected(String uri) {
        prefs.edit().putString("last", uri).apply();
    }

    void markPlayed(Game g) {
        String k = g.key();
        prefs.edit()
            .putLong("lp_" + k, System.currentTimeMillis())
            .putInt("pc_" + k, prefs.getInt("pc_" + k, 0) + 1)
            .apply();
    }

    long lastPlayed(Game g) {
        return prefs.getLong("lp_" + g.key(), 0L);
    }

    int playCount(Game g) {
        return prefs.getInt("pc_" + g.key(), 0);
    }

    // ------------------------------------------------------------ cache

    private File indexFile() {
        return new File(dir, "games.json");
    }

    private File iconFile(Game g) {
        return new File(dir, g.key() + ".icon.png");
    }

    private File picFile(Game g) {
        return new File(dir, g.key() + ".pic.png");
    }

    List<Game> loadCached() {
        List<Game> out = new ArrayList<>();
        try {
            File f = indexFile();
            if (!f.exists()) return out;
            JSONArray a = new JSONArray(new String(readAll(f), StandardCharsets.UTF_8));
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                Game g = new Game(Uri.parse(o.getString("uri")), o.optString("name", ""), o.optLong("size", 0L), o.optLong("mod", 0L));
                g.title = o.has("title") ? o.getString("title") : null;
                g.discId = o.has("disc") ? o.getString("disc") : null;
                g.hasMeta = o.optBoolean("meta", false);
                if (iconFile(g).exists()) g.iconPath = iconFile(g).getPath();
                if (picFile(g).exists()) g.picPath = picFile(g).getPath();
                out.add(g);
            }
        } catch (Exception ignored) {
            // A damaged cache is simply rebuilt by the next scan.
        }
        return out;
    }

    private void saveIndex(List<Game> list) {
        try {
            JSONArray a = new JSONArray();
            for (Game g : list) {
                JSONObject o = new JSONObject();
                o.put("uri", g.uri.toString());
                o.put("name", g.fileName);
                o.put("size", g.size);
                o.put("mod", g.modified);
                o.put("meta", g.hasMeta);
                if (g.title != null) o.put("title", g.title);
                if (g.discId != null) o.put("disc", g.discId);
                a.put(o);
            }
            writeBytes(indexFile(), a.toString().getBytes(StandardCharsets.UTF_8));
        } catch (Exception ignored) {
            // Not fatal: the library just gets scanned again next time.
        }
    }

    // ------------------------------------------------------------ scanning

    /** Scans every folder. Runs on a worker thread; progress snapshots go to cb (also on that thread). */
    List<Game> rescan(List<Game> cached, Progress cb) {
        Map<String, Game> old = new HashMap<>();
        for (Game g : cached) old.put(g.uri.toString(), g);

        List<Game> found = new ArrayList<>();
        Set<String> seen = new HashSet<>();
        for (Uri tree : folders()) scanTree(tree, found, seen);
        Collections.sort(found, new Comparator<Game>() {
            @Override
            public int compare(Game a, Game b) {
                return a.fileName.compareToIgnoreCase(b.fileName);
            }
        });

        List<Game> result = new ArrayList<>();
        for (Game g : found) {
            Game o = old.get(g.uri.toString());
            boolean same = o != null && o.hasMeta && o.size == g.size && o.modified == g.modified;
            result.add(same ? o : g);
        }
        if (cb != null) cb.onUpdate(new ArrayList<>(result));

        int parsed = 0;
        for (Game g : result) {
            if (g.hasMeta) continue;
            readMeta(g);
            parsed++;
            if (cb != null && parsed % 3 == 0) cb.onUpdate(new ArrayList<>(result));
        }
        saveIndex(result);
        return result;
    }

    private static boolean isGame(String name) {
        String n = name.toLowerCase(Locale.US);
        return n.endsWith(".iso") || n.endsWith(".cso") || n.endsWith(".pbp") || n.endsWith(".chd");
    }

    private void scanTree(Uri tree, List<Game> out, Set<String> seen) {
        try {
            walk(tree, DocumentsContract.getTreeDocumentId(tree), 0, out, seen);
        } catch (Exception ignored) {
            // Folder removed or permission lost: skip it.
        }
    }

    private void walk(Uri tree, String parentId, int depth, List<Game> out, Set<String> seen) {
        Uri children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, parentId);
        List<String> subdirs = new ArrayList<>();
        Cursor c = null;
        try {
            c = ctx.getContentResolver().query(children, COLS, null, null, null);
            while (c != null && c.moveToNext()) {
                String id = c.getString(0);
                String name = c.getString(1);
                String mime = c.getString(2);
                if (id == null || name == null) continue;
                if (Document.MIME_TYPE_DIR.equals(mime)) {
                    if (depth < 4 && !name.startsWith(".")) subdirs.add(id);
                } else if (isGame(name)) {
                    Uri doc = DocumentsContract.buildDocumentUriUsingTree(tree, id);
                    if (seen.add(doc.toString())) {
                        long size = c.isNull(3) ? 0L : c.getLong(3);
                        long mod = c.isNull(4) ? 0L : c.getLong(4);
                        out.add(new Game(doc, name, size, mod));
                    }
                }
            }
        } catch (Exception ignored) {
            // Unreadable folder: keep whatever was found so far.
        } finally {
            if (c != null) c.close();
        }
        for (String id : subdirs) walk(tree, id, depth + 1, out, seen);
    }

    private void readMeta(Game g) {
        g.hasMeta = true;
        ParcelFileDescriptor pfd = null;
        FdSource src = null;
        try {
            pfd = ctx.getContentResolver().openFileDescriptor(g.uri, "r");
            if (pfd == null) return;
            src = new FdSource(pfd);
            pfd = null; // now owned by src
            PspMeta m = PspMeta.read(src, g.fileName);
            if (m == null) return;
            g.title = m.title;
            g.discId = m.discId;
            if (m.icon != null && m.icon.length > 0) {
                File f = iconFile(g);
                writeBytes(f, m.icon);
                g.iconPath = f.getPath();
            }
            if (m.pic != null && m.pic.length > 0) {
                File f = picFile(g);
                writeBytes(f, m.pic);
                g.picPath = f.getPath();
            }
        } catch (Throwable ignored) {
            // Unsupported or unreadable file: the tile falls back to the file name.
        } finally {
            try {
                if (src != null) src.close();
                else if (pfd != null) pfd.close();
            } catch (Exception ignored) {
                // nothing more to do
            }
        }
    }

    // ------------------------------------------------------------ small IO helpers

    private static byte[] readAll(File f) throws IOException {
        FileInputStream in = new FileInputStream(f);
        try {
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
            return bo.toByteArray();
        } finally {
            in.close();
        }
    }

    private static void writeBytes(File f, byte[] data) throws IOException {
        FileOutputStream out = new FileOutputStream(f);
        try {
            out.write(data);
        } finally {
            out.close();
        }
    }
}
