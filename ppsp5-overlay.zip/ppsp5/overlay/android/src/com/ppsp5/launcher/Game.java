package com.ppsp5.launcher;

import android.net.Uri;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Locale;

/** One game file found in a library folder. */
final class Game {
    final Uri uri;
    final String fileName;
    final long size;
    final long modified;
    volatile String title;
    volatile String discId;
    volatile String iconPath;
    volatile String picPath;
    volatile boolean hasMeta;
    private String key;

    Game(Uri uri, String fileName, long size, long modified) {
        this.uri = uri;
        this.fileName = fileName == null ? "" : fileName;
        this.size = size;
        this.modified = modified;
    }

    String displayTitle() {
        String t = title;
        if (t != null && !t.isEmpty()) return t;
        String n = fileName;
        int dot = n.lastIndexOf('.');
        if (dot > 0) n = n.substring(0, dot);
        n = n.replace('_', ' ').trim();
        return n.isEmpty() ? "Untitled game" : n;
    }

    String ext() {
        int dot = fileName.lastIndexOf('.');
        return dot >= 0 ? fileName.substring(dot + 1).toUpperCase(Locale.US) : "";
    }

    /** Stable id used for cache file names and per-game settings. */
    String key() {
        if (key == null) {
            try {
                MessageDigest md = MessageDigest.getInstance("MD5");
                byte[] d = md.digest(uri.toString().getBytes(StandardCharsets.UTF_8));
                StringBuilder sb = new StringBuilder();
                for (byte b : d) sb.append(String.format(Locale.US, "%02x", b));
                key = sb.toString();
            } catch (Exception e) {
                key = Integer.toHexString(uri.toString().hashCode());
            }
        }
        return key;
    }
}
